# F5A_08_Mandy_20240611

A Pen created on CodePen.io. Original URL: [https://codepen.io/1023-Mandy/pen/bGyWRdN](https://codepen.io/1023-Mandy/pen/bGyWRdN).

The first portfolio built with w3css